/*!
 * olx-scroll-gradient.js — smooth gradient morph on scroll
 * Paints <html> so it’s always visible behind content.
 */
(() => {
  'use strict';

  // Brand colors
  const BLUE   = '#1e3a8a';
  const PURPLE = '#6a1b9a';
  const RED    = '#ff4500';

  // Stops (adjust STOP1 to bias the middle color)
  const STOP0 = 0, STOP1 = 50, STOP2 = 100;

  // Helpers
  const clamp = (n,a,b) => Math.max(a, Math.min(b, n));
  const lerp  = (a,b,t) => a + (b - a) * t;
  const hexToRgb = (hex) => {
    let h = String(hex).replace('#','').trim();
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h, 16);
    return { r:(n>>16)&255, g:(n>>8)&255, b:n&255 };
  };
  const rgbToCss = ({r,g,b}) => `rgb(${r}, ${g}, ${b})`;
  const lerpColor = (a,b,t) => ({
    r: Math.round(lerp(a.r,b.r,t)),
    g: Math.round(lerp(a.g,b.g,t)),
    b: Math.round(lerp(a.b,b.b,t)),
  });

  const TOP    = [hexToRgb(BLUE), hexToRgb(PURPLE), hexToRgb(RED)];
  const BOTTOM = [hexToRgb(RED),  hexToRgb(PURPLE), hexToRgb(BLUE)];

  const gradientAt = (t) => {
    t = clamp(t, 0, 1);
    const c0 = rgbToCss(lerpColor(TOP[0], BOTTOM[0], t));
    const c1 = rgbToCss(lerpColor(TOP[1], BOTTOM[1], t));
    const c2 = rgbToCss(lerpColor(TOP[2], BOTTOM[2], t));
    return `linear-gradient(180deg, ${c0} ${STOP0}%, ${c1} ${STOP1}%, ${c2} ${STOP2}%)`;
  };

  // 🔒 Robust progress: use window.scrollY with fallbacks
  const getT = () => {
    const top = (typeof window.scrollY === 'number')
      ? window.scrollY
      : (document.documentElement.scrollTop || document.body.scrollTop || 0);

    const max = Math.max(
      1,
      (document.documentElement.scrollHeight || 0) - window.innerHeight
    );

    return clamp(top / max, 0, 1);
  };

  function init() {
    const root  = document.documentElement;              // paint <html>
    const layer = document.getElementById('olx-scroll-bg'); // mirror to layer if present
    let lastT = -1;
    const EPS = 0.0005;

    const frame = () => {
      const t = getT();
      if (Math.abs(t - lastT) > EPS) {
        const g = gradientAt(t);
        // set both to be extra-safe across engines
        root.style.backgroundImage = g;
        root.style.background = g;
        if (layer) layer.style.background = g;
        lastT = t;
      }
      requestAnimationFrame(frame);
    };

    frame();
    window.addEventListener('resize', () => { lastT = -1; }, { passive: true });
    window.addEventListener('orientationchange', () => { lastT = -1; }, { passive: true });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) lastT = -1; });

    // Debug
    window.OLXScrollBG = {
      gradientAt,
      set: (t) => {
        const g = gradientAt(clamp(t,0,1));
        root.style.backgroundImage = g;
        root.style.background = g;
        if (layer) layer.style.background = g;
      }
    };
  }

  (document.readyState === 'loading')
    ? document.addEventListener('DOMContentLoaded', init, { once: true })
    : init();
})();
